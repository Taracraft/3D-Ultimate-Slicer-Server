# Container-Pruefung mit synthetischen Prozessen

## Gepruefter Umfang

Der Source-Preflight bleibt der normale Image-Einstieg. container_runtime.py
erganzt einen Kernelvertrag und die Ueberwachung genau eines eigenen
Supervisor-Prozesses. container_probe.py verwendet diesen Vertrag mit dem
unveraenderten kanonischen job_control.py und ausschliesslich einem frisch
erzeugten temporaeren Jobbaum. Es werden keine Engine und kein API-Server
gestartet und keine bestehenden Jobs, Modelle oder Profile eingebunden.

Die Probe erzeugt einen synthetischen Eltern-/Kindprozess, die SIGTERM
ignorieren. Der Supervisor muss seine private Prozessgruppe kontrolliert
eskalieren und vollstaendig beenden. Das Ergebnis ist nur gueltig, wenn der
Container mit Exitcode 0 und dem letzten Ereignis event=passed endet.

## Erforderliche Container-Eigenschaften

- UID ungleich 0 fuer alle vier vom Kernel gemeldeten UID-Felder.
- Alle fuenf Capability-Sets leer, NoNewPrivs=1 und Seccomp-Filtermodus=2.
- Im Worker ausschliesslich die Netzwerkschnittstelle lo.
- Gemeinsamer PID-Namensraum mit einem separaten Anker; verschiedene
  Netzwerk-Namensraeume von Worker und PID 1.
- Fuer die Abnahme: readonly Root-Dateisystem, begrenzte Prozesse und Speicher,
  beschreibbares /tmp nur als eigenes tmpfs, keine Host-/Datenvolumes.

Die Kernelpruefung allein beweist weder den Inhalt des Seccomp-Filters noch
ein vertrauenswuerdiges Docker-System oder ein unveraenderliches Dateisystem.
Diese Eigenschaften werden zusaetzlich an der Docker-Konfiguration geprueft.
Ein Umgebungsflag kann den Vertrag nicht freischalten.

## Nachstellen auf einem isolierten Docker-Testhost

Zuerst den geprueften Kontext nach INSTALLATION.md erstellen und das Image
bauen. SLICER_CHECK_IMAGE muss auf dieses lokal vorhandene Testimage zeigen.
Die folgenden Namen muessen frei sein; vorhandene Container nicht ersetzen.
Keine produktiven Volumes oder Docker-Sockets in Testcontainer einbinden.

Anker starten (er simuliert ausschliesslich die Prozesssicht der spaeteren API):

```sh
docker run -d --name studio-probe-anchor --init \
  --network=none --read-only --user=65532:65532 \
  --cap-drop=ALL --security-opt=no-new-privileges:true \
  --pids-limit=32 --memory=128m --entrypoint=python3 \
  "$SLICER_CHECK_IMAGE" -c 'import time; time.sleep(120)'
```

Worker-Probe starten:

```sh
docker run -d --name studio-probe-worker \
  --pid=container:studio-probe-anchor --network=none \
  --read-only --user=65532:65532 --cap-drop=ALL \
  --security-opt=no-new-privileges:true --pids-limit=32 --memory=128m \
  --tmpfs=/tmp:rw,nosuid,nodev,noexec,size=16m,mode=1777 \
  --entrypoint=python3 "$SLICER_CHECK_IMAGE" \
  /opt/ultimate-slicer-server/container_probe.py
docker logs studio-probe-worker
```

Auf event=ready warten, maximal 15 Sekunden. owner.supervisor_pid und
owner.identity aus diesem Ereignis erfassen. Innerhalb von 30 Sekunden die
Identitaet aus dem Anker pruefen; PID ist ausschliesslich die gerade von der
synthetischen Probe gemeldete Zahl:

```sh
docker exec studio-probe-anchor python3 -c \
  'import sys,json; sys.path.insert(0,"/opt/ultimate-slicer-server/payload"); from job_control import process_identity; print(json.dumps(process_identity(int(sys.argv[1]))))' \
  "$PID"
```

Die Ausgabe muss exakt owner.identity entsprechen. Erst dann SIGTERM senden:

```sh
docker kill --signal=TERM studio-probe-worker
docker wait studio-probe-worker
docker logs studio-probe-worker
docker rm -f studio-probe-worker studio-probe-anchor
```

Auch bei einer fehlgeschlagenen Probe ausschliesslich diese eigenen
Testcontainer entfernen. docker wait muss 0 melden. event=passed bestaetigt
Abbruchgrund worker_shutdown, gestoppte Nachfahren, entfernte Teilartefakte
und blockierten Wiederanlauf bei einem verwaisten slicing-Marker.
event=ready bestaetigt zusaetzlich den abgewiesenen zweiten Dispatcher.
Ein Exitcode ohne das abschliessende Ereignis reicht nicht als Abnahme.

Negativtest: Derselbe geschuetzte Worker ohne --pid=container:... muss bei
require_isolation mit separate_anchor_network_required abbrechen. Die
Python-Regressionen pruefen zusaetzlich Root-UID, Capabilities, fehlende
Kernelbelege, fremde Netzwerkschnittstellen und abgeschwaechte Schutzwerte.

## Stand der Teilabnahme

Auf Linux/amd64 mit zwei tatsaechlichen Docker-Containern nachgewiesen:
gemeinsame Prozesssicht bei getrenntem Netzwerk, Besitzeridentitaet vom Anker,
SIGTERM-Weiterleitung, Eskalation fuer synthetische Nachfahren, Bereinigung,
Dispatcher-Ausschluss und Wiederanlaufsperre. Beide Testcontainer wurden entfernt.

Offen bleiben der produktive Dienstzyklus mit API und Telemetrie, Race-Tests
bei Start/Shutdown, Anchor-Ausfall, Crash/Restore, Datenvolumes, die ausdrueckliche
Einbindung des Isolationsvertrags in den nativen Engine-Dispatcher und die
Engine-/TLS-/HA-Abnahmen. supervise liefert einen Prozessstatus; sein Aufrufer
muss zusaetzlich das Jobresultat und requires_recovery auswerten. Bei Timeout
wird der Supervisor nicht blind getoetet und kein Folgejob gestartet.
Das aktuelle Image bleibt container_deploy_ready=false.

## Startfreigabe und fruehe Abbrueche

Der Supervisor verwendet fuer den produktiven Aufrufer eine explizite
Bereitschafts-/Freigabe-Handschlagfolge. Der Kindprozess meldet Bereitschaft erst,
nachdem die kanonischen Signalhandler installiert sind. Ein Stop vor diesem Punkt
wird als Ablehnungstoken uebertragen und nicht als Signal an einen unvorbereiteten
Interpreter. Timeout oder Ende vor Bereitschaft liefern Wiederherstellungsbedarf;
der wartende Job bleibt unveraendert und ein Folgejob darf nicht starten.

Auf Linux/amd64 wurden drei synthetische Fehlerwege im neu gebauten, gepinnten
Quell-Preflight-Image geprueft: Stop vor Bereitschaft, ausbleibende Bereitschaft
und Ende vor Bereitschaft. In allen drei Faellen blieb der Dispatcher ungestartet.
Der fruehe Stop schrieb ein kanonisches Abbruchresultat ohne slicing-Marker; die
beiden Startfehler erhielten den queued-Zustand. Das ist keine Abnahme einer
produktiven API, Telemetrie, Engine oder eines realen Jobs. Das Image bleibt
container_deploy_ready=false.