# Lizenzgrenzen des Slicer-Servers

Die Datei LICENSE gilt nur fuer neu geschriebene eigene Dateien in diesem
Bereich. Der erzeugte Ordner payload wird aus bestehenden Studio-Quellen
zusammengestellt und dadurch NICHT neu lizenziert. Sein Manifest traegt
license_scope=inherited-unresolved, bis Herkunft und Rechte pro Datei
abgeschlossen sind. Ein erfolgreiches SHA-Ergebnis ist keine Lizenzfreigabe.

| Bestandteil | Lizenz / Status | Veroeffentlichung |
|---|---|---|
| Neuer Docker-Pruefcode und neue Dokumentation in Slicer-Server | Eigene Privatnutzungs-Lizenz, keine Quellcodeaenderungen | Rechteumfang vor Release pruefen |
| Bestehender Studio-/Worker-Code im Payload | Bisheriger Lizenz- und Urheberstatus bleibt bestehen | Dateibezogene Herkunftspruefung offen |
| Bereits unter MIT publizierte Fassungen | MIT-Rechte und Copyright-Hinweise bleiben erhalten | Keine rueckwirkende Rechteentziehung |
| Python-Basisimage und Betriebssystem | Lizenzen der konkreten Imagebestandteile | Digest, Paketliste und Hinweise vor Release erfassen |
| Bambu Studio | Upstream LICENSE: GNU AGPL Version 3 | Nicht in diesem Kontext oder Image enthalten |
| Bambu-Netzwerkplugin, weitere Engines und Profile | Jeweilige Rechte gesondert pruefen | Keine automatische Beschaffung oder Beigabe |

Die Engine ist im ersten Docker-Kontext bewusst nicht enthalten. Das ist noch
keine rechtliche Bewertung einer spaeteren Kopplung von Engine und Server.
Rechte an Maschinen-/Materialprofilen und erforderlichen Laufzeitbibliotheken
muessen ebenso belegt sein wie Rechte am Engine-Programm.

Ein oeffentliches GitHub-Repository kann nach GitHubs Bedingungen angesehen und
geforkt werden. Die gewuenschte Nutzungsbeschraenkung ist eine Lizenzbedingung,
keine technische Sperre gegen das Bearbeiten heruntergeladener Dateien.

## Quellen

- https://github.com/bambulab/BambuStudio/blob/master/LICENSE
- https://opensource.org/license/mit
- https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository

Stand der Quellenpruefung: 10.10.2026. Diese Datei ersetzt keine rechtliche
Pruefung des konkreten Releases.
